package com.example.foodpos_counter.Interface;

public interface complete_inter {

    void OrderView(String order_id);

    void OrderPrint(String order_id);

    void OrderToken(String order_id);
}
