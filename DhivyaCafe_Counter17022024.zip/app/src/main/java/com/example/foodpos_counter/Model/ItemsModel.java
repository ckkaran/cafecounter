package com.example.foodpos_counter.Model;

public class ItemsModel {
}
