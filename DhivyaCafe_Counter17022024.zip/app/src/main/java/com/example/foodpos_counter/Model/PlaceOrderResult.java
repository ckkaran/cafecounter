package com.example.foodpos_counter.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import org.json.JSONArray;

public class PlaceOrderResult {
    @SerializedName("status")
    @Expose
    private String status;

    @SerializedName("message")
    @Expose
    private String message;

    @SerializedName("orderid")
    @Expose
    private String orderid;

    @SerializedName("printerlist")
    @Expose
    private JSONArray printerlist;

    public PlaceOrderResult(String status, String message, String orderid, JSONArray printerlist) {
        this.status = status;
        this.message = message;
        this.orderid = orderid;
        this.printerlist = printerlist;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

    public JSONArray getPrinterlist() {
        return printerlist;
    }

    public void setPrinterlist(JSONArray printerlist) {
        this.printerlist = printerlist;
    }
}
